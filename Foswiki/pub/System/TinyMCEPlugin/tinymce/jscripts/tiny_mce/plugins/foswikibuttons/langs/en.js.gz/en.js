tinyMCE.addI18n('en.foswikibuttons', {
    tt_desc: "Typewriter text",
    colour_desc: "Font colour",
    attach_desc: "Manage Attachments",
    hide_desc: "Edit Foswiki markup"
});